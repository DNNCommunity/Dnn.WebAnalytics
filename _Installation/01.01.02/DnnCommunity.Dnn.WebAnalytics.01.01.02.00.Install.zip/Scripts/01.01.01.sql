

ALTER TABLE  {databaseOwner}[{objectQualifier}Community_Visits]
	DROP COLUMN ip
GO
